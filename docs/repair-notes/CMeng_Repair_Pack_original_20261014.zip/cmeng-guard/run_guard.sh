#!/bin/bash
# CMeng guard: read-only run on every page of every project, then compare with the starting point.
# Usage: CMENG_BASE_URL=http://localhost:PORT ./run_guard.sh <results_folder> [--require N1,W1]
# Needs: node with playwright (Chromium), python3. Sends GET requests only.
set -e
cd "$(dirname "$0")"
OUT=${1:-run}; shift || true
PAR=${PAR:-4}
mkdir -p "$OUT/cap" "$OUT/docs" "$OUT/res"
# 1. capture every page, tab and role view (non-GET requests are blocked in the browser)
cat projects.txt | xargs -P "$PAR" -I{} bash -c 'p="{}"; d="'"$OUT"'/cap/$(echo "$p" | tr "()" "__")"; node capture_sys.mjs "$p" "$d" > /dev/null 2> "$d.err"'
# 2. document reading records
OUT="$OUT/docs" python3 fetch_documents.py $(cat projects.txt)
# 3. apply every rule
python3 sysguard.py "$OUT/cap" "$OUT/docs" "$OUT/res"
# 4. ratchet against the starting point
python3 guard_compare.py starting_point_b3c76d6.json "$OUT/res" "$@"
