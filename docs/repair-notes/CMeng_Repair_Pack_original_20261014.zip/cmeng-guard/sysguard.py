"""CMeng system guard: rules that apply to every page of every project.

Reads the read-only capture (capture_sys.mjs) and the document reading records,
then scores each rule on each page. The rules carry no project names and no
expected figures. Usage: python3 sysguard.py <capture_root> <docs_dir> <out_dir>
"""
import json, re, sys, os, gzip, glob, collections

CAP, DOCS, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- rule catalogue
RULES = [
 # id, family, plain rule, how it is checked
 ('N1', 'Numbers', 'A list cut to 25 rows is never counted, totalled or drawn as the whole list.', 'Server paging record says total > rows sent; the screen shows that table without its full total, or says "of 25".'),
 ('N2', 'Numbers', 'An unknown value is never shown as 0, "0 of 0", "No" or "No known".', 'A tile or line shows 0 next to an unknown word, or shows "0 of 0" or "No known".'),
 ('N3', 'Numbers', 'A unit is never printed after an unknown word.', 'Text such as "Not established days" or "Not in source %".'),
 ('N4', 'Numbers', 'The same measure shows the same value on every page of a project.', 'A fixed list of project measures (critical, negative float, near-critical, contract date, finish dates, progress, EOT, contract value, EAC, open RFIs/NCRs, late packages) is read from every page and compared.'),
 ('N5', 'Numbers', 'A role view shows the same value as the overall view for the same measure.', 'Same measure list, role view text compared with the overall view of the same page.'),
 ('N6', 'Numbers', 'Numbers and dates are formatted for people.', 'No raw timestamps, no more than 2 decimals, thousands separators on numbers of 5+ digits, no "4k" style short forms, no NaN, undefined, null or Invalid Date.'),
 ('N7', 'Numbers', 'Durations and float are shown in days with the day type, never in hours.', 'Values such as "-740 h" or "h/month".'),
 ('N9', 'Numbers', 'Paging reaches every row.', 'A register page asks the server for 50 rows, gets 25, and Next moves on by 50.'),
 ('N11', 'Numbers', 'An ID column never repeats one value on every row.', 'In the rows the server sends for a table, an item / number / code / ID field has the same value on 10 or more rows.'),
 ('N8', 'Numbers', 'No impossible values.', 'Percentages above 100, negative counts.'),
 ('S1', 'States', 'Every unknown value says why and what is needed.', 'A tile shows Not established / Not in source / Not available / Not assessable with no reason or next step.'),
 ('S2', 'States', 'An empty table says why it is empty.', 'A table with no rows shows only the generic "No reviewed rows in this view" or no message.'),
 ('S3', 'States', 'A chart is never drawn empty.', 'Chart box with "No numeric series points" or no bars, points or lines.'),
 ('S4', 'States', 'A good-news badge never sits on a bad number.', '"Good" or "Passed" next to a negative or missing value.'),
 ('W1', 'Wording', 'No data field names on screen.', 'Screen phrases that are the server field names of that page turned into words (e.g. "Checks Activity Ids", "Known Open Count"), and camelCase or snake_case words.'),
 ('W2', 'Wording', 'No internal or technical words on screen.', 'Fixed list: fallback, deterministic, native:, population, payload, stub, pointer, session ids, identity unverified, source semantics, rerun, not_configured.'),
 ('W3', 'Wording', 'File names are shown as uploaded, never cut or lower-cased.', 'Patterns such as "s03 latest_U02_..." or "p01 procurement_Register...".'),
 ('W4', 'Wording', 'Plurals and counts agree; no doubled words.', '"1 activities", "1 records", "3 record", "the the".'),
 ('W5', 'Wording', 'A sentence is said once per page.', 'A sentence of 8+ words that appears 3 or more times on one page.'),
 ('W6', 'Wording', 'Each page has its own headline.', 'The page headline or first banner is word for word the same as on another page.'),
 ('W7', 'Wording', 'No raw source row lists or ID dumps in text.', 'A line with 5+ "row N" references or 12+ record IDs.'),
 ('W8', 'Wording', 'No phrase from the do-not-use list (every wording defect found once is added here).', 'Fixed phrase list: "Do not blame", "individual not designated", "This is not a zero result", "No canonical management action", "management truth", "fail-closed", "causation unproven", "Calculation Withheld", "Records disagree" mid-sentence, and others.'),
 ('W9', 'Wording', 'One unknown word per value.', 'Two unknown words side by side, e.g. "Not established · Not available" or "Not in source / Not in source".'),
 ('C1', 'Choices', 'When two values disagree, the page shows both and lets the user pick one or enter another.', 'The page says values conflict or disagree, and has no Confirm / Choose / Use / Accept control.'),
 ('L1', 'Look', 'A page fits its purpose: default view 3 screens or less.', 'Default view height over 3 screens of 700 px.'),
 ('L2', 'Look', 'No raw data sections.', '"Additional source records" sections or "View 25 source records" buttons.'),
 ('L3', 'Look', 'No overloaded pages.', 'More than 15 collapsed sections, more than 15 tables, or an opened page over 20 screens.'),
 ('L4', 'Look', 'Nothing runs off the screen.', 'Page wider than the window at 1366 px.'),
 ('A1', 'Actions', 'Every button goes to a page that exists.', 'Button target is not a menu page or tab.'),
 ('A2', 'Actions', 'No button sends the user back to the same page.', 'Button target equals the current page.'),
 ('A3', 'Actions', 'An action is listed in one place.', 'The same action sentence on 5 or more pages of a project.'),
 ('A4', 'Actions', 'Every action has a named owner and a due date.', 'Owner shown as Not assigned / Not recorded / Suggested / Not designated, or due date Not established.'),
 ('R1', 'Reading', 'Every source column is read or shown to the user as not used.', 'Document reading record lists ignored columns.'),
 ('R2', 'Reading', 'Every file type is identified from its content.', 'Identified by file name or metadata fallback, OCR sample only, flagged for review, or type conflict.'),
 ('R3', 'Reading', 'Every file is read completely or says what part was not read.', 'Reading record says not complete.'),
 ('R4', 'Reading', 'Programme links attach to activities.', '"native:" keys on screen.'),
 ('R5', 'Reading', 'When reading is incomplete and AI is set up, the screen says so.', 'AI configured but owner permission needed, while R1-R3 problems exist.'),
 ('P1', 'Speed', 'Every page opens within 5 seconds.', 'Measured from menu click to loaded (4 projects read at once).'),
 ('P2', 'Speed', 'No load errors.', 'HTTP error, browser error or page that never finished loading.'),
]
RULE = {r[0]: r for r in RULES}

UNK = r'(?:Not established|Not in source|Not available|Not assessable|Not calculated|Not provided|Not recorded|Not confirmed|Unknown)'
REASON = re.compile(r'(?i)\b(because|until|needs?|require[sd]?|upload|confirm|missing|not supplied|no supplied|supply|provide|awaiting|pending|enter|add |select|choose|review|no .{0,30}(register|file|record|value|date|column)|without|cannot|not (yet )?(read|linked|mapped|supplied|dated))')


BANNED = re.compile(r'(?i)do not blame|gap is that the contractor did not submit|individual not designated|this is not a zero result|not derivable|no canonical management action|management truth|fail-closed|causation unproven|identity association|temporal association|calculation withheld|scenario only|immutable determination|cutoff-controlled|money-linked claim population|correction route requires review|review classification is not yet available|source details are paged|next step: review the figures for this page|not necessarily records disagree|compare the records disagree|information still required|governed (records|amendment|programme)|requires? correction and repeat the check|unresolved source semantics|check pending')


def T(s):
    return re.sub(r'\s+', ' ', s or '').strip()


def snippet(text, m, w=90):
    a, b = max(0, m.start() - w), min(len(text), m.end() + w)
    return T(text[a:b])


def load_api(d):
    out = []
    for f in sorted(glob.glob(f'{d}/api_*.json.gz')):
        try:
            out.append(json.loads(gzip.open(f).read()))
        except Exception:
            pass
    return out


def resolve(obj, pointer):
    cur = obj
    for part in pointer.strip('/').split('/'):
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except Exception:
                return None
        elif isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


def keys_of(o, acc, depth=0):
    if depth > 12:
        return
    if isinstance(o, dict):
        for k, v in o.items():
            acc.add(k)
            keys_of(v, acc, depth + 1)
    elif isinstance(o, list):
        for v in o[:3]:
            keys_of(v, acc, depth + 1)


def words_of_key(k):
    w = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', k).replace('_', ' ').split()
    return [x.capitalize() for x in w]


TECH_END = {'Iso', 'Ids', 'Refs', 'Id', 'Key', 'Pointer', 'Json', 'Kind'}

# ---------------------------------------------------------------- measures for N4 / N5
DATE = r'(?:[A-Z][a-z]{2} \d{1,2}, \d{4})'
NUM = r'(?:-?\d{1,3}(?:,\d{3})+|-?\d+)(?:\.\d+)?'
VAL = rf'({DATE}|{NUM}\s*%?|{UNK})'
INT = r'(?:\d{1,3}(?:,\d{3})+|\d+)'
TYPES = {
 'count': rf'({INT}|{UNK})(?![\d.,%/]| ?%| ?days?| ?h\b| ?/)',
 'date': rf'({DATE}|{UNK})',
 'days': rf'(-?{INT} ?(?:calendar |working )?(?:days?|d)\b|{UNK})',
 'pct': rf'({NUM} ?%|{UNK})',
}
MEASURES = [
 ('Critical activities', r'(?<!near-)(?<!near )critical activities', 'count'),
 ('Negative float activities', r'negative float activities|activities (?:with|on) negative float', 'count'),
 ('Near-critical activities', r'near-critical activities|near-critical', 'count'),
 ('Contractual completion', r'contract(?:ual)? completion(?: date)?', 'date'),
 ('Extended contract date', r'extended contract(?:ual)? (?:completion|date)(?: with awarded eot)?', 'date'),
 ('Submitted finish', r'submitted (?:programme |forecast )?(?:completion|finish)(?: date)?', 'date'),
 ('Data Date', r'data date', 'date'),
 ('Awarded EOT', r'awarded eot(?: days)?', 'days'),
 ('Open RFIs', r'open rfis?', 'count'),
 ('Open NCRs', r'open (?:ncrs?|non-?conformance reports?)', 'count'),
 ('Late packages', r'(?:late|overdue) (?:procurement )?packages', 'count'),
 ('Schedule progress', r'(?:schedule|overall|programme) progress', 'pct'),
]
HISTORY_PAGES = {'revision-trend', 'forecast-history', 'windows-analysis', 'variance-trends', 'schedule-change-report', 'milestones'}


def measures(text, drop=()):
    # A measure is read only where the screen shows it as a tile: a label line, then a value line,
    # then a line that is not another bare number (which would mean a grid or chart axis).
    for d in drop:
        text = text.replace(d, ' ')
    lines = [l.strip() for l in text.split('\n')]
    lines = [l for l in lines if l]
    found = collections.defaultdict(set)
    for i, line in enumerate(lines[:-1]):
        if '\t' in line or len(line) > 60:
            continue
        for name, lab, typ in MEASURES:
            if re.fullmatch(rf'(?i)(?:{lab})', line):
                val = lines[i + 1]
                nxt = lines[i + 2] if i + 2 < len(lines) else ''
                if re.fullmatch(TYPES[typ], val) and not re.fullmatch(r'[-\d,.% ]+', nxt) and not re.fullmatch(DATE, nxt):
                    found[name].add(val)
    return found


def norm_val(v):
    if re.match(UNK, v):
        return 'unknown'
    return v.replace(',', '').replace(' ', '')


# ---------------------------------------------------------------- checker
def check_project(pdir, docs):
    hits = []
    meta = json.load(open(f'{pdir}/meta.json'))
    nav_keys = {n['key'] for n in meta['nav']}
    pages = []
    for pj in sorted(glob.glob(f'{pdir}/*/page.json')):
        d = os.path.dirname(pj)
        rec = json.load(open(pj))
        rec['dir'] = d
        rec['text_d'] = open(f'{d}/text_default.txt').read() if os.path.exists(f'{d}/text_default.txt') else ''
        rec['text_e'] = open(f'{d}/text_expanded.txt').read() if os.path.exists(f'{d}/text_expanded.txt') else ''
        rec['roles_t'] = {os.path.basename(f)[10:-4]: open(f).read() for f in glob.glob(f'{d}/text_role_*.txt')}
        pages.append(rec)
    tab_keys = {t['key'] for p in pages for t in p['default']['header'].get('tabs', [])}
    app = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app', 'modules.json')))
    all_keys = nav_keys | tab_keys | {p['key'] for p in pages} | set(app['modules']) | set(app['special'])

    def hit(rule, page, ev, n=1):
        hits.append(dict(rule=rule, page=page['key'] if page else '(project)', title=(page['default']['header'].get('title') if page else ''), evidence=T(ev)[:240], n=n))

    linefreq = collections.Counter()
    for p in pages:
        linefreq.update({l.strip() for l in p['text_d'].split('\n') if l.strip()})
    global_lines = {l for l, n in linefreq.items() if n >= max(3, len(pages) // 2)}
    page_meas = {}
    headlines = collections.defaultdict(list)
    action_pages = collections.defaultdict(set)
    for p in pages:
        te, td = p['text_e'], p['text_d']
        inv = p.get('inv', {})
        apis = load_api(p['dir'])
        # N1 cut lists
        for a in apis:
            rp = a.get('responsePaging') or {}
            for t in rp.get('tables', []):
                if t.get('total', 0) <= t.get('shown', 0):
                    continue
                arr = resolve(a, t['pointer'])
                if not isinstance(arr, list) or not arr:
                    continue
                first = arr[0]
                vals = set()
                if isinstance(first, dict):
                    for v in first.values():
                        if isinstance(v, (str, int, float)) and len(str(v)) >= 3:
                            vals.add(str(v))
                elif isinstance(first, (str, int)) and len(str(first)) >= 4:
                    vals.add(str(first))
                for tb in inv.get('tables', []):
                    cells = {c for row in tb.get('sample', [])[:1] for c in row}
                    if not cells or not vals:
                        continue
                    ov = sum(1 for v in vals if any(v == c or (len(v) > 6 and v in c) for c in cells))
                    if ov >= min(2, len(vals)):
                        foot = tb.get('foot', '')
                        tot = t['total']
                        shown_tot = re.search(r'of ([\d,]+)', foot)
                        ftot = int(shown_tot.group(1).replace(',', '')) if shown_tot else None
                        if ftot is not None and ftot < tot:
                            hit('N1', p, f'Table "{tb.get("section", "")[:60]}" footer "{foot[:90]}" while the server list holds {tot:,} rows ({t["pointer"]}).')
                        elif ftot is None and f'{tot:,}' not in te and str(tot) not in te:
                            hit('N1', p, f'Table "{tb.get("section", "")[:60]}" shows {tb.get("rows")} rows; the full total {tot:,} is not on the page ({t["pointer"]}).')
        # N1 text and tile forms; N9 double paging of register pages
        paged_tot = [t for a in apis for t in ((a.get('responsePaging') or {}).get('tables') or []) if t.get('total', 0) > t.get('shown', 0)]
        big = [t for t in paged_tot if t['pointer'] != '/rows']
        if big:
            for m in re.finditer(r'Showing (?:1[–-])?(25|50) of (25|50)\b[^\n]{0,40}', te):
                hit('N1', p, f'"{m.group(0)}" while the server holds lists of up to {max(t["total"] for t in big):,} rows')
            for k in inv.get('kpis', []):
                if re.search(r'(^|\| )25( \||$)', k):
                    hit('N1', p, f'Tile "{k[:160]}" shows 25, the page size, while the server holds lists of up to {max(t["total"] for t in big):,} rows')
        for t in paged_tot:
            if t['pointer'] == '/rows':
                hit('N9', p, f'Register page asked for {t["total"]} rows and received {t["shown"]}; rows {t["shown"] + 1} to {t["total"]} of each page cannot be reached')
                break
        # N11 constant ID column
        def arrays(o, path='', depth=0):
            if depth > 8:
                return
            if isinstance(o, list) and len(o) >= 10 and all(isinstance(r, dict) for r in o[:10]):
                yield path, o
            if isinstance(o, dict):
                for k, v in o.items():
                    yield from arrays(v, path + '/' + k, depth + 1)
            elif isinstance(o, list):
                for i, v in enumerate(o[:3]):
                    yield from arrays(v, path + '/' + str(i), depth + 1)
        seen_n11 = set()
        for a in apis:
            for path, arr in arrays(a.get('data', {})):
                for k in arr[0].keys():
                    if not re.search(r'(?i)(item(no|number|id)?|code|number|^no$|id)$', k) or k in seen_n11:
                        continue
                    vals = [r.get(k) for r in arr if isinstance(r, dict)]
                    if len(vals) >= 10 and all(isinstance(v, (str, int)) and v not in ('', None) for v in vals) and len(set(map(str, vals))) == 1:
                        seen_n11.add(k)
                        if re.search(rf'(?<![\w-]){re.escape(str(vals[0]))}(?![\w-])', te):
                            hit('N11', p, f'Field "{k}" is "{vals[0]}" on all {len(vals)} rows of {path}')
        # N2 unknown shown as zero
        for k in inv.get('kpis', []):
            if re.search(r'(^|\| )0(\.0+)?( ?%| SAR| days?)?( \||$)', k) and re.search(rf'(?i){UNK}|not confirmed|missing|not supplied|no supplied|unknown|not dated', k):
                hit('N2', p, f'Tile "{k[:200]}"')
        for m in re.finditer(r'No known blockers?|No known (issues?|risks?)', te):
            hit('N2', p, snippet(te, m))
        for m in re.finditer(r'\b0 of 0 matching', te):
            hit('S2', p, 'Empty list with no reason: ' + snippet(te, m, 60))
        # N3 unit after unknown
        for m in re.finditer(rf'{UNK}\s*(days?|d|h|hours?|%|SAR|USD|AED|activities|records)\b', te):
            hit('N3', p, snippet(te, m, 50))
        # N6 formats
        for pat, why in [(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}', 'raw timestamp'), (r'(?<![\w.])\d+\.\d{3,}(?![\w.])', 'more than 2 decimals'),
                         (r'(?<![\w\-:#/.,])(?:[1-9]\d{4,})(?![\w\-.,%])', 'no thousands separator'), (r'(?<![\w.])\d+(?:\.\d+)?k\b', 'short form k'),
                         (r'\b(NaN|undefined|null|Invalid Date|\[object Object\]|Infinity)\b', 'broken value')]:
            for m in re.finditer(pat, te):
                s = m.group(0)
                if why == 'no thousands separator':
                    ctx = te[max(0, m.start() - 12):m.end() + 6]
                    if re.search(r'(?i)(row|id|no\.?|ref|page|version|v)\s*$', te[max(0, m.start() - 8):m.start()]) or re.match(r'(19|20)\d{2}$', s):
                        continue
                hit('N6', p, f'{why}: ' + snippet(te, m, 50))
        # N7 hours
        for m in re.finditer(r'(?<![\w.])-?\d[\d,]*(?:\.\d+)? ?h\b(?!\w)|h/month', te):
            hit('N7', p, snippet(te, m, 50))
        # N8 impossible
        for m in re.finditer(r'(?<![\w.\-])(\d{3,}(?:\.\d+)?) ?%', te):
            if float(m.group(1)) > 100:
                hit('N8', p, snippet(te, m, 50))
        for m in re.finditer(r'(?<![\w])-\d[\d,]* (records|activities|items|packages)\b', te):
            hit('N8', p, snippet(te, m, 50))
        # S1 bare unknown tiles
        for k in inv.get('kpis', []):
            if re.search(UNK, k) and not REASON.search(k):
                hit('S1', p, f'Tile "{k[:200]}"')
        # S2 empty tables
        for tb in inv.get('tables', []):
            if tb.get('rows', 0) == 0 or tb.get('empty'):
                hit('S2', p, f'Table "{tb.get("section", "")[:70]}" headings {", ".join(tb.get("head", [])[:6])}: {tb.get("foot") or "no message"}')
        # S3 empty charts
        for c in inv.get('charts', []):
            if re.search(r'No numeric series points|No signed movement is established|[Nn]o (?:data|values|points|series) (?:is |are )?(?:available|established|supplied)', c.get('text', '')):
                hit('S3', p, f'Chart "{c.get("head", "")[:80]}" is empty')
        # S4 good badge on bad value
        for m in re.finditer(rf'\b(Good|PASSED|On Track)\b[^\n]{{0,40}}(-\d[\d,]*|{UNK})|(-\d[\d,]* (?:calendar |working )?days?)[^\n]{{0,25}}\bGood\b', te):
            hit('S4', p, snippet(te, m, 40))
        # W1 field names
        ks = set()
        for a in apis:
            keys_of(a.get('data', a), ks)
        phrases = set()
        for k in ks:
            w = words_of_key(k)
            if len(w) >= 3 or (len(w) >= 2 and w[-1] in TECH_END):
                phrases.add(' '.join(w))
        seen = set()
        for ph in sorted(phrases, key=len, reverse=True):
            for m in re.finditer(rf'(?<![A-Za-z]){re.escape(ph)}(?![a-z])', te):
                if any(ph in s for s in seen):
                    break
                seen.add(ph)
                hit('W1', p, f'"{ph}": ' + snippet(te, m, 40))
                break
        for m in re.finditer(r'\b[a-z]+[A-Z][a-z]+[A-Za-z]*\b|\b[a-z]+_[a-z][a-z_]+\b', te):
            hit('W1', p, f'"{m.group(0)}": ' + snippet(te, m, 40))
        # W2 internal words
        for m in re.finditer(r'(?i)\bfallback\b|\bdeterministic\b|native:|\bpopulation\b|\bpayload\b|\bstub\b|\bpointer\b|Session [0-9a-f]{8}|identity unverified|source semantics|\brerun\b|not_configured', te):
            hit('W2', p, f'"{m.group(0)}": ' + snippet(te, m, 50))
        # W3 mangled file names
        for m in re.finditer(r'\b[a-z]{1,4}\d{2} [a-z]+_[A-Za-z0-9_\-.]+', te):
            hit('W3', p, m.group(0)[:120])
        # W4 grammar
        for m in re.finditer(r'(?<![\d,.\-/])1 (records|activities|risks|items|packages|groups|candidates|representatives|rows|documents|claims|events|calendars|tasks|issues|actions|notices|letters|qualifications|sources|values)\b', te):
            hit('W4', p, snippet(te, m, 40))
        for m in re.finditer(r'(?<![\d.\-/])(?:[2-9]|\d{2,}|\d{1,3}(?:,\d{3})+) (record|activity|risk|item|package|group|row|document|claim|task|action)\b(?![-(/s])', te):
            hit('W4', p, snippet(te, m, 40))
        for m in re.finditer(r'\b([A-Za-z]{2,}) \1\b', te):
            if m.group(1).lower() not in ('that', 'had'):
                hit('W4', p, snippet(te, m, 40))
        # W5 repeated sentences
        sents = collections.Counter()
        for line in te.split('\n'):
            if '\t' in line:
                continue
            for s in re.split(r'(?<=[.!?])\s+', line.strip()):
                if len(s.split()) >= 8:
                    sents[s.strip()] += 1
        for s, n in sents.items():
            if n >= 3:
                hit('W5', p, f'x{n}: {s[:200]}', n)
        # W6 headline per page
        lines = [l.strip() for l in td.split('\n') if len(l.strip().split()) >= 8 and l.strip() not in global_lines]
        if lines:
            headlines[re.sub(r'\d[\d,.]*', '#', lines[0])].append(p)
        # W7 row lists and ID dumps
        for line in te.split('\n'):
            if len(re.findall(r'\brow \d+', line)) >= 5:
                hit('W7', p, line[:200])
            elif len(re.findall(r'\b[A-Z]{2,}[A-Z0-9]*-\d{2,}\b|native:::\d+', line)) >= 12 and '\t' not in line:
                hit('W7', p, line[:200])
        # W8 do-not-use phrases
        for m in re.finditer(BANNED, te):
            hit('W8', p, f'"{m.group(0)}": ' + snippet(te, m, 50))
        # W9 double unknown
        for m in re.finditer(rf'{UNK}\s*[·/:+|]\s*{UNK}', te):
            hit('W9', p, snippet(te, m, 40))
        # C1 conflict without a choice
        cm = re.search(r'(?i)\b(?:score conflict|date conflict|value conflict|classification conflict|source conflict|conflicting (?:values|dates|evidence|records|sources)|sources? (?:disagree|conflict)|reporting groups disagree|records disagree(?![ \t]*\d)|disagree(?:s|ment)? (?:with|between))\b', te)
        if cm and not any(re.match(r'(?i)(confirm|choose|select|use |use$|accept|adopt|keep|pick)', b['text']) for b in inv.get('buttons', [])):
            hit('C1', p, 'Conflict shown with no way to choose: ' + snippet(te, cm, 80))
        # L1-L4
        hd, he = p['default'].get('height', 0), p['expanded'].get('height', 0)
        if hd > 3 * 700:
            hit('L1', p, f'Default view {hd / 700:.1f} screens', round(hd / 700, 1))
        n_add = len(re.findall(r'Additional source records', te))
        n_v25 = sum(1 for b in inv.get('buttons', []) if re.match(r'View \d+ source records', b['text']))
        if n_add or n_v25:
            hit('L2', p, f'{n_add} "Additional source records" sections, {n_v25} "View 25 source records" buttons', n_add + n_v25)
        ncol = sum(1 for x in p['default'].get('details', []) if not x.get('open') and x.get('visible'))
        ntab = len(inv.get('tables', []))
        if ncol > 15 or ntab > 15 or he > 20 * 700:
            hit('L3', p, f'{ncol} collapsed sections, {ntab} tables, {he / 700:.1f} screens when opened')
        if inv.get('sw', 0) > inv.get('cw', 0) + 2:
            hit('L4', p, f'Page width {inv.get("sw")} px in a {inv.get("cw")} px window')
        # A1 A2 A4
        for b in inv.get('buttons', []):
            tgt = b['attrs'].get('data-module') or b['attrs'].get('data-target-module')
            if tgt and tgt not in all_keys:
                hit('A1', p, f'Button "{b["text"]}" goes to "{tgt}", which is not a page')
            elif tgt == 'documents' and re.search(r'(?i)owner|owning', b['text']):
                hit('A1', p, f'Button "{b["text"]}" opens the document library, the fallback used when no owning page is set')
            if tgt and tgt == p['key']:
                hit('A2', p, f'Button "{b["text"]}" reopens this page')
        for m in re.finditer(r'Not assigned|Not recorded|Suggested: [^\n\t]{0,40}|Individual Not Designated|Owner[:\s]+Not established|Due[^\n\t]{0,10}Not established', te):
            hit('A4', p, snippet(te, m, 40))
        # A3 collect action sentences
        for line in te.split('\n'):
            s = line.strip()
            if 6 <= len(s.split()) <= 40 and re.match(r'(Review|Confirm|Reconcile|Establish|Upload|Investigate|Resolve|Supply|Provide|Link|Assign|Record|Approve|Obtain|Update)\b', s):
                action_pages[re.sub(r'\d[\d,.]*', '#', s)].add(p['key'])
        # R4
        for m in re.finditer(r'native:', te):
            hit('R4', p, snippet(te, m, 40))
            break
        # P1 P2
        if p.get('loadMs', 0) > 5000:
            hit('P1', p, f'Opened in {p["loadMs"] / 1000:.1f} s', round(p['loadMs'] / 1000, 1))
        bad = [a for a in p.get('api', []) if a.get('status', 200) >= 400]
        if bad or p.get('state') != 'loaded' or p.get('errors'):
            hit('P2', p, f'{len(bad)} HTTP errors {[a["status"] for a in bad][:3]}, state {p.get("state")}, {len(p.get("errors", []))} browser errors: {(p.get("errors") or [""])[0][:120]}')
        # N4 / N5 measures
        page_meas[p['key']] = measures(te, [c.get('text', '') for c in inv.get('charts', [])])
        for rv, rt in p['roles_t'].items():
            rm = measures(rt)
            for name, vals in rm.items():
                ov = page_meas[p['key']].get(name)
                if ov:
                    a = {norm_val(v) for v in vals}; b = {norm_val(v) for v in ov}
                    if a.isdisjoint(b):
                        hit('N5', p, f'{rv} view: {name} {", ".join(sorted(vals))}; overall view: {", ".join(sorted(ov))}')
    # N4 across pages
    allm = collections.defaultdict(lambda: collections.defaultdict(set))
    for k, mm in page_meas.items():
        if k in HISTORY_PAGES:
            continue
        for name, vals in mm.items():
            for v in vals:
                allm[name][v].add(k)
    for name, vals in allm.items():
        known = {norm_val(v) for v in vals if norm_val(v) != 'unknown'}
        if len(known) > 1 or (known and 'unknown' in {norm_val(v) for v in vals}):
            desc = '; '.join(f'{v} on {len(ps)} page(s) e.g. {sorted(ps)[0]}' for v, ps in sorted(vals.items(), key=lambda x: -len(x[1]))[:5])
            hits.append(dict(rule='N4', page='(project)', title='', evidence=f'{name}: {desc}'[:400], n=len(vals)))
    # W6 shared headlines
    for h, ps in headlines.items():
        titles = {p['default']['header'].get('title') for p in ps}
        if len(titles) > 1:
            for p in ps:
                hit('W6', p, f'Same headline on {len(ps)} pages ({", ".join(sorted(t or "" for t in titles))[:120]}): {h[:120]}')
    # A3 repeated actions
    for s, ks in action_pages.items():
        if len(ks) >= 5:
            hits.append(dict(rule='A3', page='(project)', title='', evidence=f'On {len(ks)} pages: {s[:180]}', n=len(ks)))
    # R1-R3, R5 from document reading records
    reading_issue = False
    for x in docs:
        name = x.get('sourceFilename', '?')
        for cu in x.get('columnUsage') or []:
            if cu.get('ignoredColumns'):
                reading_issue = True
                hits.append(dict(rule='R1', page='(documents)', title=name, evidence=f'{name}: columns not used: {", ".join(cu["ignoredColumns"])}', n=len(cu['ignoredColumns'])))
        idf = x.get('identification') or {}
        if idf.get('method') in ('metadata_fallback', 'filename', 'filename_hint', 'ocr_sample') or idf.get('needsReview') or idf.get('classificationConflict'):
            reading_issue = True
            hits.append(dict(rule='R2', page='(documents)', title=name, evidence=f'{name}: identified as {x.get("documentType")} by {idf.get("method")}, needs review {idf.get("needsReview")}, conflict {idf.get("classificationConflict")}'))
        rr = x.get('readReview') or {}
        if rr.get('complete') is False or x.get('parserState') not in (None, 'parsed'):
            reading_issue = True
            hits.append(dict(rule='R3', page='(documents)', title=name, evidence=f'{name}: {rr.get("label")}; {T(rr.get("note"))[:150]}'))
    ai = meta.get('ai') or {}
    if reading_issue and ai.get('providerConfigured') and ai.get('ownerPermissionRequired'):
        hits.append(dict(rule='R5', page='(project)', title='', evidence=f'AI {ai.get("model")} is set up but needs owner permission; reading problems above remain and no page says AI could read them.'))
    return meta, pages, hits


def main():
    summary = {}
    for pdir in sorted(glob.glob(f'{CAP}/*/')):
        pdir = pdir.rstrip('/')
        if not os.path.exists(f'{pdir}/summary.json') and not os.environ.get('PARTIAL'):
            continue  # capture not finished
        meta = json.load(open(f'{pdir}/meta.json'))
        proj = meta['project']
        dp = f'{DOCS}/docsfull_{proj}.json'
        docs = json.load(open(dp))['documents'] if os.path.exists(dp) else []
        meta, pages, hits = check_project(pdir, docs)
        json.dump(dict(project=proj, release=meta['release'], pages=len(pages), documents=len(docs), hits=hits), open(f'{OUT}/{proj}.json', 'w'), indent=1)
        c = collections.Counter(h['rule'] for h in hits)
        pg = collections.defaultdict(set)
        for h in hits:
            pg[h['rule']].add(h['page'])
        summary[proj] = dict(pages=len(pages), documents=len(docs), hits=dict(c), pages_hit={k: len(v) for k, v in pg.items()})
        print(proj, len(pages), 'pages', sum(c.values()), 'hits', dict(c), flush=True)
    json.dump(dict(rules=RULES, projects=summary), open(f'{OUT}/summary.json', 'w'), indent=1)


if __name__ == '__main__':
    main()
