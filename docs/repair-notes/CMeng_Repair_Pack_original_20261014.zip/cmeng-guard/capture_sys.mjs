// CMeng system guard: read-only capture of every page, workspace tab and role view of one project.
// Blocks every non-GET request at the browser. Writes text, element inventory and server data per page.
// Usage: node capture_sys.mjs <PROJECT> <OUTDIR>
let chromium; try { ({ chromium } = await import('playwright')); } catch (e) { ({ chromium } = await import('/opt/npm-tools/node_modules/playwright/index.mjs')); }
import fs from 'fs';
import zlib from 'zlib';
const PROJECT = process.argv[2];
const OUT = process.argv[3];
const BASE = process.env.CMENG_BASE_URL || 'https://cmeng-main-production.up.railway.app/';
fs.mkdirSync(OUT, { recursive: true });
const log = (...a) => { fs.appendFileSync(`${OUT}/run.log`, a.join(' ') + '\n'); };
const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
const blocked = [];
await ctx.route('**/*', r => { const m = r.request().method(); if (!['GET', 'HEAD', 'OPTIONS'].includes(m)) { blocked.push(m + ' ' + r.request().url()); return r.abort(); } return r.continue(); });
await ctx.addInitScript(p => { try { localStorage.setItem('cmeng-project', p); localStorage.setItem('cmeng-role-view', 'overall'); } catch (e) {} }, PROJECT);
const page = await ctx.newPage();
page.on('dialog', d => d.dismiss().catch(() => {}));
let apiLog = []; let errs = [];
page.on('response', async r => {
  const u = r.url(); if (!u.includes('/api/projects/')) return;
  const rec = { url: u.replace(BASE, '/'), status: r.status() }; apiLog.push(rec);
  if (!/\/modules\//.test(u) || /report\.(json|xlsx)/.test(u)) return;
  try { const b = await r.body(); rec.len = b.length; if (b.length < 60e6) { rec.file = `api_${apiLog.length}.json.gz`; rec.buf = zlib.gzipSync(b); } } catch (e) {}
});
page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
page.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 300)); });
const t0 = Date.now();
await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 180000 });
for (let i = 0; i < 600; i++) { const s = await page.evaluate(() => (typeof projectLoadState !== 'undefined' ? projectLoadState : '') + '|' + document.querySelectorAll('button.nav-item[data-key]').length); if (s.startsWith('ready') && !s.endsWith('|0')) break; await page.waitForTimeout(500); }
const health = await page.evaluate(async () => (await (await fetch('/health')).json()));
const nav = await page.evaluate(() => [...document.querySelectorAll('button.nav-item[data-key]')].map(b => ({ key: b.dataset.key, label: b.innerText.trim(), group: (b.closest('.nav-group, section, details')?.querySelector('.nav-group-title, summary, h3, h4')?.innerText || '').trim().slice(0, 60) })));
fs.writeFileSync(`${OUT}/meta.json`, JSON.stringify({ project: PROJECT, release: health.release, calculationVersion: health.calculationVersion, ai: health.ai || null, nav, bootMs: Date.now() - t0 }, null, 1));
async function waitLoaded() { await page.waitForTimeout(500); for (let i = 0; i < 600; i++) { const busy = await page.evaluate(() => { const b = (document.getElementById('moduleBadge')?.textContent || '').trim(); return b === 'Updating' || b === 'Calculating' || !!document.querySelector('#moduleContent .view-state-bar .spinner'); }); if (!busy) return 'loaded'; await page.waitForTimeout(200); } return 'timeout'; }
const snap = () => page.evaluate(() => {
  const mc = document.getElementById('moduleContent');
  const vis = e => !!(e && e.offsetParent);
  const T = e => (e?.innerText || '').trim();
  const header = { title: document.getElementById('moduleTitle')?.innerText, subtitle: document.getElementById('moduleSubtitle')?.innerText, tabs: [...document.querySelectorAll('#moduleWorkspaceTabs button')].map(b => ({ key: b.dataset.key, label: b.innerText.trim() })), roles: [...document.querySelectorAll('[data-role-view]')].filter(vis).map(b => b.dataset.roleView) };
  const details = [...mc.querySelectorAll('details')].map(d => ({ summary: T(d.querySelector('summary')).split('\n')[0].slice(0, 160), open: d.open, visible: vis(d.querySelector('summary')) }));
  return { header, details, height: mc.scrollHeight, text: mc.innerText };
});
const inventory = () => page.evaluate(() => {
  const root = document.getElementById('moduleContent');
  const T = e => (e?.innerText || '').trim();
  const vis = e => !!(e && e.offsetParent);
  const kpis = [...root.querySelectorAll('.planning-kpi, .scalar, .kpi, .metric-card, .position-card, .experience-kpi, .kpi-card')].filter(vis).map(e => T(e).replace(/\s*\n\s*/g, ' | ').slice(0, 300));
  const charts = [...root.querySelectorAll('.visual-chart, .chart-card, svg.svg-chart')].filter(vis).filter(e => !e.parentElement.closest('.visual-chart, .chart-card')).map(e => {
    const sec = e.closest('section, .planning-panel, details, .panel'); const h = sec && sec.querySelector('h2,h3,h4,summary,.planning-panel-head');
    return { head: (T(e.querySelector('.visual-chart-head, .chart-card-head')) || (h ? T(h) : '')).slice(0, 160), points: e.querySelectorAll('.chart-hit-point').length, bars: e.querySelectorAll('.visual-bar-row, rect').length, paths: e.querySelectorAll('path, polyline').length, axis: [...e.querySelectorAll('text')].map(x => x.textContent.trim()).filter(Boolean).slice(0, 60), legend: [...e.querySelectorAll('.legend-item, .chart-legend span')].map(T).slice(0, 14), text: T(e).slice(0, 800) };
  });
  const tables = [...root.querySelectorAll('table')].filter(vis).map(t => {
    const wrap = t.closest('.table-wrap') || t.parentElement;
    const rows = [...t.querySelectorAll('tbody tr')];
    let foot = ''; let n = wrap; for (let i = 0; i < 3 && n; i++) { n = n.nextElementSibling; const tx = T(n); if (/Showing|No rows|matching rows|source records/.test(tx)) { foot = tx.replace(/\s+/g, ' ').slice(0, 200); break; } }
    const sec = t.closest('details, section, .planning-panel, .panel'); const h = sec && sec.querySelector(':scope > summary, h2, h3, h4, .planning-panel-head');
    return { section: (h ? T(h) : '').split('\n')[0].slice(0, 160), head: [...t.querySelectorAll('thead th')].map(T).slice(0, 40), rows: rows.length, sample: rows.slice(0, 3).map(r => [...r.children].map(c => T(c).replace(/\s+/g, ' ').slice(0, 120))), foot, empty: T(wrap).includes('No reviewed rows') || T(wrap).includes('No rows in this view') };
  });
  const notices = [...root.querySelectorAll('.notice, .missing_information, .evidence-gate, .callout, .warning, .banner')].filter(vis).map(e => T(e).replace(/\s+/g, ' ').slice(0, 600));
  const controls = [...root.querySelectorAll('select, input, textarea')].filter(vis).map(e => ({ tag: e.tagName, type: e.type || '', label: (e.getAttribute('aria-label') || e.placeholder || e.name || e.id || '').slice(0, 80) }));
  const seen = new Set(); const buttons = [];
  for (const b of root.querySelectorAll('button, a')) { if (!vis(b)) continue; const tx = T(b).slice(0, 100); if (!tx) continue; const a = {}; for (const at of b.attributes) if (/^(data-|href|onclick)/.test(at.name)) a[at.name] = at.value.slice(0, 200); const k = tx + JSON.stringify(a); if (seen.has(k)) continue; seen.add(k); buttons.push({ text: tx, attrs: a, disabled: !!b.disabled }); }
  return { kpis, charts, tables, notices, controls, buttons: buttons.slice(0, 400), sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth };
});
const done = new Set(); const summary = [];
async function processPage(key, loadMs, state) {
  if (done.has(key)) return; done.add(key);
  const dir = `${OUT}/${key}`; fs.mkdirSync(dir, { recursive: true });
  await page.evaluate(() => window.scrollTo(0, 0)); await page.waitForTimeout(200);
  const def = await snap();
  fs.writeFileSync(`${dir}/text_default.txt`, def.text); delete def.text;
  try { await page.screenshot({ path: `${dir}/screen01.jpg`, type: 'jpeg', quality: 50 }); } catch (e) {}
  for (let k = 0; k < 4; k++) { await page.evaluate(() => document.querySelectorAll('#moduleContent details:not([open])').forEach(d => { d.open = true; })); await page.waitForTimeout(300); }
  const exp = await snap();
  fs.writeFileSync(`${dir}/text_expanded.txt`, exp.text); delete exp.text;
  const inv = await inventory();
  const roles = {};
  for (const rv of def.header.roles.filter(r => r !== 'overall')) {
    const r0 = Date.now();
    await page.evaluate(k => document.querySelector(`[data-role-view="${k}"]`)?.click(), rv);
    await waitLoaded();
    const t = await page.evaluate(() => document.getElementById('moduleContent')?.innerText || '');
    fs.writeFileSync(`${dir}/text_role_${rv}.txt`, t); roles[rv] = { words: t.split(/\s+/).length, ms: Date.now() - r0 };
  }
  if (Object.keys(roles).length) { await page.evaluate(() => document.querySelector('[data-role-view="overall"]')?.click()); await waitLoaded(); }
  const apis = apiLog.filter(a => a.buf); for (const a of apis) { fs.writeFileSync(`${dir}/${a.file}`, a.buf); delete a.buf; }
  const rec = { key, loadMs, state, default: def, expanded: exp, inv, roles, api: apiLog.map(a => ({ url: a.url, status: a.status, len: a.len, file: a.file })), errors: errs };
  fs.writeFileSync(`${dir}/page.json`, JSON.stringify(rec, null, 1));
  summary.push({ key, title: def.header.title, loadMs, state, words: exp.details.length, errors: errs.length });
  log(key, def.header.title, 'loadMs', loadMs, state);
  apiLog = []; errs = [];
}
for (const n of nav) {
  apiLog = []; errs = [];
  const c0 = Date.now();
  await page.evaluate(k => document.querySelector(`button.nav-item[data-key="${k}"]`)?.click(), n.key);
  const st = await waitLoaded(); const ms = Date.now() - c0;
  const current = await page.evaluate(() => document.querySelector('#moduleWorkspaceTabs button[aria-current="page"]')?.dataset.key || null);
  await processPage(current || n.key, ms, st);
  const tabs = await page.evaluate(() => [...document.querySelectorAll('#moduleWorkspaceTabs button')].map(b => b.dataset.key));
  for (const t of tabs) {
    if (done.has(t)) continue;
    apiLog = []; errs = [];
    const c1 = Date.now();
    await page.evaluate(k => document.querySelector(`#moduleWorkspaceTabs button[data-key="${k}"]`)?.click(), t);
    const st2 = await waitLoaded(); await processPage(t, Date.now() - c1, st2);
  }
}
fs.writeFileSync(`${OUT}/summary.json`, JSON.stringify({ project: PROJECT, release: health.release, pages: summary, blocked, totalMs: Date.now() - t0 }, null, 1));
log('done pages', summary.length, 'blocked non-GET', blocked.length, 'ms', Date.now() - t0);
await browser.close();
