"""Independent source reader: works out key figures straight from a project's source files,
with its own simple code, then looks for each figure on CMeng's screens.

It finds file types by their columns, not by file names or project names, so the same code
runs on any project whose source files are available.
Usage: python3 -I reader.py <source_folder> <text_folder_or_-> <capture_project_dir> <out.json>
"""
import csv, json, re, sys, os, glob, datetime as dt, collections

SRC, TXT, CAPD, OUTP = sys.argv[1:5]


def low(h):
    return re.sub(r'[^a-z0-9]+', ' ', h.lower()).strip()


def pdate(s):
    s = (s or '').strip()
    for cand in (s, s[:10], s[:16]):
        for f in ('%Y-%m-%d', '%d-%b-%Y', '%d/%m/%Y', '%Y-%m-%d %H:%M', '%d %B %Y', '%d %b %Y'):
            try:
                return dt.datetime.strptime(cand, f).date()
            except Exception:
                pass
    return None


def col(headers, *names):
    for n in names:
        for h in headers:
            if low(h) == n or low(h).startswith(n):
                return h
    return None


M = []  # (topic, measure, value, kind)


def add(topic, name, value, kind='count'):
    M.append(dict(topic=topic, measure=name, value=value, kind=kind))


def xer(path):
    t, cur, f = {}, None, None
    for line in open(path, encoding='utf-8', errors='replace'):
        line = line.rstrip('\r\n')
        if line.startswith('%T'):
            cur = line.split('\t')[1]; t[cur] = []; f = None
        elif line.startswith('%F'):
            f = line.split('\t')[1:]
        elif line.startswith('%R') and cur and f:
            t[cur].append(dict(zip(f, line.split('\t')[1:])))
    return t


# ---- programmes: the latest by data date
progs = []
for p in glob.glob(f'{SRC}/**/*.xer', recursive=True):
    t = xer(p)
    pj = (t.get('PROJECT') or [{}])[0]
    progs.append((pj.get('last_recalc_date') or '', p, t))
progs.sort()
if progs:
    for i, (dd, p, t) in enumerate(progs):
        pj = (t.get('PROJECT') or [{}])[0]
        tag = 'latest programme' if i == len(progs) - 1 else f'programme {i + 1}'
        if pj.get('plan_end_date'):
            add('programme', f'Planned project finish ({tag}, PROJECT table)', pdate(pj['plan_end_date']), 'date')
    dd, p, t = progs[-1]
    tasks, preds = t.get('TASK', []), t.get('TASKPRED', [])
    ids = {x.get('task_id') for x in tasks}
    add('programme', 'Activities in latest programme', len(tasks))
    valid = sum(1 for r in preds if r.get('task_id') in ids and r.get('pred_task_id') in ids and r.get('task_id') != r.get('pred_task_id'))
    add('programme', 'Programme relationships that join two activities', valid)
    st = collections.Counter(x.get('status_code') for x in tasks)
    for k, lab in (('TK_Complete', 'Activities complete'), ('TK_Active', 'Activities in progress'), ('TK_NotStart', 'Activities not started')):
        if st.get(k):
            add('programme', lab, st[k])
    for c in t.get('CALENDAR', []):
        h = c.get('day_hr_cnt') or c.get('hours_per_day')
        if h:
            add('programme', f'Working hours per day, calendar {c.get("clndr_name")}', float(h), 'hours')
    codes = collections.Counter(x.get('task_code') for x in tasks)
    dup = [k for k, n in codes.items() if n > 1]
    if dup:
        add('programme', 'Duplicate activity IDs', len(dup))

# ---- registers, recognised by their columns
for p in glob.glob(f'{SRC}/**/*.csv', recursive=True):
    rows = list(csv.DictReader(open(p, encoding='utf-8-sig')))
    if not rows:
        continue
    H = list(rows[0].keys()); L = {low(h) for h in H}
    status = col(H, 'status')
    sc = collections.Counter((r.get(status) or '').strip() for r in rows) if status else {}
    if {'metric'} <= L and any('value' in x for x in L):
        vcol = [h for h in H if 'value' in low(h)][0]
        for r in rows:
            try:
                add('cost', r[col(H, 'metric')], float(r[vcol]), 'money')
            except Exception:
                pass
        continue
    if 'required on site' in L:
        topic = 'procurement'
        for k in ('Overdue', 'Delivered'):
            if sc.get(k):
                add(topic, f'Packages with status {k}', sc[k])
        req, fc = col(H, 'required on site'), col(H, 'forecast delivery')
        late = sum(1 for r in rows if pdate(r.get(fc)) and pdate(r.get(req)) and pdate(r[fc]) > pdate(r[req]) and (r.get(status) or '') != 'Delivered')
        add(topic, 'Undelivered packages forecast after required-on-site date', late)
    elif 'days claimed' in L:
        topic = 'claims'
        for k in sc:
            add(topic, f'Claims with status {k}', sc[k])
        for c in ('days claimed', 'days granted'):
            h = col(H, c)
            add(topic, f'Total {c}', sum(float(re.sub(r'[^0-9.\-]', '', r.get(h) or '') or 0) for r in rows))
    elif 'tag installed' in L:
        topic = 'assets'
        for c in ('tag installed', 'commissioned', 'o m manual'):
            h = col(H, c)
            if h:
                yes = sum(1 for r in rows if (r.get(h) or '').strip().lower() in ('yes', 'y', 'received', 'true', 'valid'))
                add(topic, f'Assets with {h} = yes/received', yes)
        h = col(H, 'criticality')
        if h:
            for k, n in collections.Counter(r.get(h) for r in rows).items():
                add(topic, f'Assets with criticality {k}', n)
    elif 'ncr id' in L:
        topic = 'quality'
        for k in sc:
            add(topic, f'NCRs with status {k}', sc[k])
        ra, cl = col(H, 'raised date'), col(H, 'close date')
        add(topic, 'NCRs closed before they were raised', sum(1 for r in rows if pdate(r.get(cl)) and pdate(r.get(ra)) and pdate(r[cl]) < pdate(r[ra])))
    elif 'submitted date' in L:
        topic = 'submittals'
        for k in sc:
            add(topic, f'Submittals with status {k}', sc[k])
        sd, ad = col(H, 'submitted date'), col(H, 'approval date')
        add(topic, 'Submittals approved before they were submitted', sum(1 for r in rows if pdate(r.get(ad)) and pdate(r.get(sd)) and pdate(r[ad]) < pdate(r[sd])))
    elif 'risk id' in L:
        for k in sc:
            add('risks', f'Risks with status {k}', sc[k])
    elif 'rfi id' in L:
        for k in sc:
            add('rfis', f'RFIs with status {k}', sc[k])
    elif 'variation id' in L:
        h = [x for x in H if 'amount' in low(x)]
        add('variations', 'Variations', len(rows))
        if h:
            add('variations', 'Total approved variation amount', sum(float(r.get(h[0]) or 0) for r in rows), 'money')

# ---- contract text (searchable PDFs turned to text)
if TXT != '-':
    for p in glob.glob(f'{TXT}/*.txt'):
        t = re.sub(r'\s+', ' ', open(p, errors='replace').read())
        for m in re.finditer(r'(?i)revised contractual completion date is (\d{1,2} \w+ \d{4})', t):
            add('contract', 'Revised contractual completion (amendment)', pdate(m.group(1)), 'date')
        for m in re.finditer(r'(?i)(?:Time for Completion|Original Completion|Completion Date)[^.]{0,60}?(\d{1,2} \w+ \d{4})', t):
            add('contract', 'Original completion (contract)', pdate(m.group(1)), 'date'); break
        for m in re.finditer(r'(?i)Accepted Contract Amount[^.]{0,40}?SAR ?([\d,]+)', t):
            add('contract', 'Accepted contract amount', float(m.group(1).replace(',', '')), 'money'); break
        for m in re.finditer(r'(?i)extended by (\d+) calendar days', t):
            add('contract', 'Time extension in amendment (days)', int(m.group(1)), 'days')

# de-duplicate
seen, MM = set(), []
for m in M:
    k = (m['measure'], str(m['value']))
    if k not in seen:
        seen.add(k); MM.append(m)


# ---- look for each figure on CMeng's screens
def forms(m):
    v, k = m['value'], m['kind']
    if k == 'date' and v:
        return [v.strftime('%b %-d, %Y'), v.strftime('%-d %b %Y'), v.isoformat()]
    if k in ('count', 'days') or (isinstance(v, float) and v.is_integer() and k != 'money' and k != 'hours'):
        n = int(v)
        return [f'{n:,}', str(n)] if n >= 1000 else [str(n)]
    if k == 'hours':
        n = int(v) if float(v).is_integer() else v
        return [f'{n} h', f'{n}h', f'{n} hours', f'{n}-hour', f'{n} hrs']
    if k == 'money':
        n = int(v); out = [f'{n:,}']
        for div, suf in ((1e9, 'B'), (1e6, 'M')):
            if n >= div:
                x = n / div
                for d in (0, 1, 2):
                    s = f'{x:.{d}f}'
                    if abs(float(s) - x) < 1e-9:
                        out += [s + suf, s + ' ' + suf, s + (' billion' if suf == 'B' else ' million')]
        return out
    return [str(v)]


texts = {}
for f in glob.glob(f'{CAPD}/*/text_expanded.txt'):
    texts[f.split('/')[-2]] = open(f).read()
res = []
for m in MM:
    fs = forms(m)
    pages = sorted(k for k, t in texts.items() if any(re.search(rf'(?<![\d.,]){re.escape(x)}(?![\d,]|\.\d)', t) for x in fs))
    m2 = dict(m); m2['value'] = str(m['value']); m2['forms'] = fs[:3]; m2['pages'] = pages; m2['shown'] = bool(pages)
    # a small number turns up by chance on many pages, so finding it proves little
    m2['strong'] = m['kind'] in ('date', 'money') or (isinstance(m['value'], (int, float)) and m['value'] >= 100)
    res.append(m2)
json.dump(res, open(OUTP, 'w'), indent=1)
for r in res:
    print(('SHOWN  ' if r['shown'] else 'MISSING'), 'strong' if r['strong'] else 'weak  ', r['topic'], '|', r['measure'], '=', r['value'], '|', len(r['pages']), 'pages', r['pages'][:3])
