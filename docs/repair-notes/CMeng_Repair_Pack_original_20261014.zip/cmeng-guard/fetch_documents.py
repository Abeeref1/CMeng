import json,sys,urllib.request,urllib.parse
import os
B=os.environ.get('CMENG_BASE_URL','https://cmeng-main-production.up.railway.app').rstrip('/')
for P in sys.argv[1:]:
    q=urllib.parse.quote(P,safe='')
    d=json.load(urllib.request.urlopen(f'{B}/api/projects/{q}/evidence/documents',timeout=180))
    docs=list(d.get('documents',[])); total=d.get('documentCount',len(docs)); ver=d.get('projectVersion'); off=len(docs)
    while off<total:
        src=urllib.parse.quote(f'/api/projects/{P}/evidence/documents',safe='')
        r=json.load(urllib.request.urlopen(f'{B}/api/projects/{q}/record-page?source={src}&pointer=%2Fdocuments&offset={off}&limit=25&q=&version={ver}',timeout=180))
        rows=r.get('rows',[])
        if not rows: break
        docs+=rows; off+=len(rows)
    json.dump({'project':P,'version':ver,'documents':docs},open(os.path.join(os.environ.get('OUT','.'),f'docsfull_{P}.json'),'w'))
    print(P,len(docs),'of',total, flush=True)
