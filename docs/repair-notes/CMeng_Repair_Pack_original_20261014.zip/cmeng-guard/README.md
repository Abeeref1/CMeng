# CMeng guard

This is the regression guard from the CMeng Repair Plan (section "How the work is checked", layer 3). It runs 39 rules on every page, tab and role view of every project and compares the result with the starting point. It only reads: the browser blocks every request that is not a GET.

## What is in this folder

| File | What it does |
| --- | --- |
| `run_guard.sh` | Runs everything below in order |
| `capture_sys.mjs` | Opens every menu page, workspace tab and role view of one project and saves the page text, tiles, tables, buttons, charts, load time and the server data behind the page |
| `fetch_documents.py` | Saves each project's document reading records (columns read and ignored, how each file was identified, whether it was fully read) |
| `sysguard.py` | Applies the 39 rules to every page and writes one result file per project plus `summary.json` |
| `guard_compare.py` | The ratchet: compares a run with the starting point and says PASSES or BLOCKED |
| `starting_point_b3c76d6.json` | The starting point: 11,822 failing checks out of 43,401, taken on release b3c76d6 on 13 Oct 2026 |
| `locked_rules.txt` | Rules locked after reaching zero (owner or verifier only) |
| `reader.py` | Independent source reader: works out key figures from a project's source files and looks for them on the screens |
| `projects.txt` | The 23 projects in the starting point |
| `app/modules.json` | The page list the button check uses |

## How to run

```
npm install playwright      # once; Chromium must be available
CMENG_BASE_URL=http://localhost:PORT ./run_guard.sh runs/<commit> --require <rules for this build>
```

`CHROME_PATH` points at a Chromium binary if Playwright cannot find one. `PAR` sets how many projects run at once (default 4). Run it against a build of the commit being checked that holds the same 23 projects' data. A full run takes about 30 minutes.

## How a build passes

1. Nothing that passes in the starting point now fails, on any rule, project or page.
2. No locked rule fails anywhere. L4, A2 and P2 are at zero in the starting point, so they are locked now.
3. Every rule named with `--require` (the rules for the items in that build) is at zero.

`guard_compare.py` exits with 0 when the build passes and 1 when it is blocked, and lists every new failure.

## Rules for using it

- Only the owner or the verifier changes the starting point, the rules or `locked_rules.txt`.
- Never change wording, hide data or remove a page section just to pass a rule. Fix the value, the logic or the screen.
- Every new finding is added as a rule, a phrase on the do-not-use list (`BANNED` in `sysguard.py`) or a reader case before it closes.
- This guard stops defects coming back. It does not prove calculations are right; the independent calculators and the stage challenge do that.
- This is the first full version. If a rule gives a wrong result, report it to the owner or verifier with the page and the evidence; do not edit the rule.
