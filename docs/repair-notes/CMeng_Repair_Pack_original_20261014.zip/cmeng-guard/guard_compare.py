"""Compare a new guard run with the starting point (the ratchet).

A build passes when:
  1. nothing that passed in the starting point now fails (no new rule / project / page failure);
  2. no locked rule fails anywhere (a rule locks when it has zero failures in the starting point,
     or when the owner or verifier adds it to locked_rules.txt after it reaches zero);
  3. every rule named with --require is at zero (the rules for the items in this build).

Usage:
  python3 guard_compare.py starting_point_b3c76d6.json <results_dir> [--require N1,W1]
Exit code 0 = passes, 1 = blocked.
"""
import json, glob, os, sys, collections

start_path, res_dir = sys.argv[1], sys.argv[2]
require = set()
if '--require' in sys.argv:
    require = set(sys.argv[sys.argv.index('--require') + 1].split(','))


def norm(page):
    return '*' if page in ('(project)', '(documents)') else page


start = {(r, p, norm(pg)) for r, p, pg in json.load(open(start_path))}
now = set()
rules = []
for f in glob.glob(os.path.join(res_dir, '*.json')):
    if f.endswith('summary.json'):
        rules = [r[0] for r in json.load(open(f))['rules']]
        continue
    d = json.load(open(f))
    for h in d['hits']:
        now.add((h['rule'], d['project'], norm(h['page'])))
if not rules:
    rules = sorted({x[0] for x in start | now})

here = os.path.dirname(os.path.abspath(__file__))
locked = {r for r in rules if not any(x[0] == r for x in start)}
lf = os.path.join(here, 'locked_rules.txt')
if os.path.exists(lf):
    locked |= {l.strip() for l in open(lf) if l.strip() and not l.startswith('#')}

projects_now = {x[1] for x in now}
new_fail = sorted(x for x in now - start)
fixed = sorted(x for x in start - now if x[1] in projects_now)
locked_fail = sorted(x for x in now if x[0] in locked)
require_fail = sorted(x for x in now if x[0] in require)

by_rule = collections.Counter(x[0] for x in now)
print(f'Starting point failures: {len(start):,}   Now: {len(now):,}   Fixed: {len(fixed):,}   New failures: {len(new_fail):,}')
print('Locked rules:', ', '.join(sorted(locked)) or 'none')
print('Rules now at zero:', ', '.join(r for r in rules if by_rule[r] == 0) or 'none')
for title, rows in (('NEW FAILURES (something that passed now fails)', new_fail),
                    ('LOCKED RULE FAILURES', locked_fail),
                    ('REQUIRED RULES NOT AT ZERO', require_fail)):
    if rows:
        print(f'\n{title}: {len(rows)}')
        for r, p, pg in rows[:200]:
            print(f'  {r}  {p}  {pg}')
blocked = bool(new_fail or locked_fail or require_fail)
print('\nRESULT:', 'BLOCKED' if blocked else 'PASSES THE GUARD')
sys.exit(1 if blocked else 0)
